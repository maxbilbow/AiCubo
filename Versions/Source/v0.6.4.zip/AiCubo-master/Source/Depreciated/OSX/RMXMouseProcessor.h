//
//  RMXMouseProcessor.h
//  RattleGL3.0
//
//  Created by Max Bilbow on 09/03/2015.
//  Copyright (c) 2015 Rattle Media. All rights reserved.
//

#ifndef RattleGL3_0_RMXMouseProcessor_h
#define RattleGL3_0_RMXMouseProcessor_h


#endif

//#define RX_MOUSE_INVERT (-1)
//#define RX_MOUSE_STANDARD 1
//
//#define MARGIN 0

                        // Initial window height
void center();
void MouseButton(int button, int state, int x, int y);
void MouseMotion(int x, int y);
void MouseFree(int x, int y);